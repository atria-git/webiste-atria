<div class="container">

	<div class="row">
		
		<div class="col-lg-5 col-md-6" data-aos="fade-up" data-aos-delay="">
			<div class="about-img">
				<img src="<?php echo base_url($data->image) ?>" style="width: 100%;">
			</div>
		</div>

		<div class="col-lg-7 col-md-6" data-aos="fade-up" data-aos-delay="">
			<div class="about-content">
				<?php echo $data->content ?>
			</div>
		</div>

	</div>

</div>
