<style type="text/css">
	.product-title {
		-webkit-box-orient: vertical;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: normal;
		font-size: 22px !important;
		margin: 0 0 5px !important;
	}
  .title-short{
    color: #ad0000;
    line-height: 19px;

  }
  @media screen and (max-width:768px) and (max-width:992px){
  .probootstrap-featured-news-box .probootstrap-text h1 {
    font-size: 13px;
    margin: 0 0 0px;
    font-weight: 500;
    line-height: 18px;
  }
  .product-title {
    margin: 0 0 5px;
    font-size: 14px;
  }
  .body{
      font-family: Quicksand,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;
  }
  .probootstrap-featured-news-box:focus .probootstrap-text,.probootstrap-featured-news-box:hover .probootstrap-text{background:#32c787;top:-40px;-webkit-box-shadow:0 2px 20px 0 rgba(0,0,0,.1);box-shadow:0 2px 20px 0 rgba(0,0,0,.1); font-size: 13px;!important}
  .title-short{
    line-height: 15px;
    font-size: 13px;
  }
  @media only screen and (max-width: 740px){
.probootstrap-featured-news-box .probootstrap-text {
  line-height: 14px;
}
.title-short{
  font-size: 10px;
}

}
  
  }
</style>
<head>
<!-- Google / Search Engine Tags -->
<meta itemprop="name" content="Atria Dimensi Solusindo - The Security Solutions">
<meta itemprop="description" content="Beli Kamera Cctv Dahua dan CP Plus Online berkualitas dengan harga murah terbaru 2021 di Atria, Menyediakan produk-produk keamanan berkualitas dan bergaransi resmi dari distributor, siap melayani untuk pengadaan CCTV dan alat keamanan untuk perusahaan, industri, hotel, apartemen dll | Hubungi 081908232299 untuk konsultasinya">
<meta itemprop="image" content="https://atriadimensi.com/directory/dashboard/f1448053bb197a616b5a4185d71b9f1e.jpg">

<!-- Facebook Meta Tags -->
<meta property="og:url" content="https://atriadimensi.com">
<meta property="og:type" content="website">
<meta property="og:title" content="Atria Dimensi Solusindo - The Security Solutions">
<meta property="og:description" content="Beli Kamera Cctv Dahua dan CP Plus Online berkualitas dengan harga murah terbaru 2021 di Atria, Menyediakan produk-produk keamanan berkualitas dan bergaransi resmi dari distributor, siap melayani untuk pengadaan CCTV dan alat keamanan untuk perusahaan, industri, hotel, apartemen dll | Hubungi 081908232299 untuk konsultasinya ">
<meta property="og:image" content="https://atriadimensi.com/directory/dashboard/f1448053bb197a616b5a4185d71b9f1e.jpg">

<!-- Twitter Meta Tags -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Atria Dimensi Solusindo - The Security Solutions">
<meta name="twitter:description" content="Beli Kamera Cctv Dahua dan CP Plus Online berkualitas dengan harga murah terbaru 2021 di Atria, Menyediakan produk-produk keamanan berkualitas dan bergaransi resmi dari distributor, siap melayani untuk pengadaan CCTV dan alat keamanan untuk perusahaan, industri, hotel, apartemen dll | Hubungi 081908232299 untuk konsultasinya">
<meta name="twitter:image" content="https://atriadimensi.com/directory/dashboard/f1448053bb197a616b5a4185d71b9f1e.jpg">
<meta name="Description" content= "Beli Kamera Cctv Dahua dan CP Plus Online berkualitas dengan harga terbaik dan terbaru 2021 di Atria, 
Menyediakan produk-produk keamanan berkualitas dan bergaransi resmi dari distributor, 
siap melayani untuk pengadaan CCTV dan alat keamanan untuk perusahaan, industri, hotel, apartemen dll 
| Hubungi 081908232299 untuk konsultasinya">
</head>

<section class="probootstrap-section" style="padding-top: 0px; padding-bottom: 0px;">
  <?php if (count($data) > 0): ?>
  <div class="row">
    <?php foreach ($data as $item): ?>
    <div class="col-md-4 col-sm-6 col-xs-6 col-xxs-6 probootstrap-animate">
      <a href="<?php echo base_url('product/'.$item->link) ?>" class="probootstrap-featured-news-box">
        <figure class="probootstrap-media">
          <img src="<?php echo base_url($item->image1) ?>" srcset="<?php echo base_url($item->image1) ?> 480w, <?php echo base_url($item->image1) ?> 1080w" sizes="50vw" alt="<?php echo $item->name ?>" class="img-responsive" style="width: 100%; height: 250px; object-fit: cover;">
        </figure>
        <div class="probootstrap-text">
					<div style="height: 80px; ">
						<h1 class="product-title" style=" height: 35px !important;"><?php echo $item->name ?></h1>
						<span class="title-short"><?php echo $item->title_short ?></span>
						<span style="color: #012b18 !important; float: right; font-size: 12px;"><?php echo ($item->sold_out <= $item->stock) ? 'Tersedia' : 'Kosong' ?></span>
          </div>
        </div>
      </a>
    </div>
    <?php endforeach; ?>
  </div>
  <?php else: ?>
  <div class="nothing-found"><div>No data found</div></div>
  <?php endIf; ?>

  <div class="text-center probootstrap-animate">
    <?php echo $pagination ?>
  </div>
</section>
