
<style>
.media-body, .media-left, .media-right {
    display: contents !important;
    vertical-align: top;
}
@media (max-width: 767px){
.hidden-xs {
    display: none!important;
}
}
@media only screen and (max-width: 740px){
  .media-body, .media-left, .media-right {
  display: contents;
  }
.judulblog{
  line-height: 31px !important;
  font-size: 21px;
  FONT-WEIGHT: 500;
}
.isicontent{

}
.img-cover{
  width:100%!important;
}
}
</style>



<div class="row">
  <div class="col-sm-8 col-xs-12 probootstrap-animate" style="margin-bottom: 30px;">
    <div class="card">
      <div class="card-body">
        <div class="media">
          <div class="media-body">
            <h1 class="judulblog"style="margin-bottom: 4px; line-height: 1.1;"><?php echo $data->title ?></h1>
            <div style="margin-bottom: 20px;color: #306246;"><?php echo date("d M Y • H:i:s", strtotime($data->created_at)) ?></div>
            <img class="img-cover mb-4" src="<?php echo base_url($data->cover) ?>" srcset="<?php echo base_url($data->cover) ?> 480w, <?php echo base_url($data->cover) ?> 1080w"  sizes="50vw" width="640" height="360" alt="<?php echo $data->title ?>" style="width: 100%; object-fit: cover; height: auto; padding-bottom: 20px;" />
            <span style="line-height: 1.7 !important;"<?php echo $data->content ?>
          </div>
        </div>
      </div>
    </div>
    <?php
      if ($data->is_comment == 1) {
        include_once('comment.php');
      };
    ?>
  </div>
  <div class="col-sm-4 col-xs-12 right-panel probootstrap-animate">
    <div style="font-size: 20px; border-bottom: 4px solid #32c787; color: #32c787; margin-bottom: 30px;">
      Latest Posts
    </div>

    <?php if (count($data_latest) > 0): ?>
    <?php foreach ($data_latest as $item): ?>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12 col-xxs-12 probootstrap-animate">
        <a href="<?php echo base_url('blog/'.$item->link) ?>" class="probootstrap-featured-news-box">
          <figure class="probootstrap-media">
            <img src="<?php echo base_url($item->cover) ?>" srcset="<?php echo base_url($item->cover) ?> 480w, <?php echo base_url($item->cover) ?> 1080w"  sizes="50vw" width="640" height="360" alt="<?php echo $item->title ?>" class="img-responsive" style="width: 100%; height: 200px; object-fit: cover;">
          </figure>
          <div class="probootstrap-text">
            <h3><?php echo $item->title ?></h3>
            <div class="probootstrap-date" style="font-size: 13px;">
              <i class="icon-calendar"></i><?php echo date("d M Y", strtotime($item->created_at)) ?>
              <?php if ($item->is_comment == 1): ?>
              <div style="float: right;">
                <i class="zmdi zmdi-comments"></i> <?php echo number_format((int)$item->comment_count) ?>
              </div>
              <?php endif; ?>
            </div>
          </div>
        </a>
      </div>
    </div>
    <?php endForeach; ?>
    <?php else: ?>
    <div class="nothing-found"><div>Nothing found</div></div>
    <?php endIf ?>
    
  </div>
</div>
