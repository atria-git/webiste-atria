<style>

@media screen and (max-width: 480px){
.flexslider, .flexslider .slides>li, .slider-height {
    height: 233px !important;
}
.flexslider .probootstrap-slider-text {
    margin-top: 98px !important;
}

}
@media only screen and (max-width: 768px){
  .partner{
     width: 100% !important;
  }
  .judul{
   font-size: 30px;
   font-weight: 400;
    }
.mobile-menu-grid .menu-item img {
    font-size: 12px;
    height: 50px !important;
}
}
.card-body {
    -webkit-box-flex: 1;
    -ms-flex: 1 1 auto;
    flex: 1 1 auto;
    padding: 1.25rem;
}
.body-container{
 margin: 14px;
  transition: 0.3s;
  border-radius: 5px;
  text-align: center;
}
.partner {
  border-radius: 5px 5px 0 0;
  margin-bottom: 11px;
}
.card-header {
    padding: .75rem 1.25rem;
    margin-bottom: 0;
    background-color: rgba(0,0,0,.03);
    border-bottom: 1px solid rgba(0,0,0,.125);
}
.main {
  max-width: 1000px;
  margin: auto;
}

.row-polio{
  margin: 8px -16px;
}

.subtitle{
    text-overflow: ellipsis; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
        margin: auto;
        font-size: x-large;
}
/* Add padding BETWEEN each column */
.row-polio,
.row-polio > .column {
  padding: 8px;
}

/* Create four equal columns that floats next to each other */
.column {
  float: left;
  width: 50%;
}

/* Clear floats after rows */ 
.row-polio:after {
  content: "";
  display: table;
  clear: both;
}

/* Content */
.content {
  background-color: white;
  padding: 10px;
  text-align: center;
}

/* Responsive layout - makes a two column-layout instead of four columns */
@media screen and (max-width: 900px) {
  .column {
    width: 50%;
  }
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
  }
}
.column.main .block:last-child {
    margin-bottom: 0;
}

.block-static-block.widget, .block-cms-link.widget {
    margin-bottom: 20px;
}
.widget {
    clear: both;
}
.mobile-menu-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr 1fr;
    grid-gap: 5px;
    padding: 15px;
}

.mobile-menu-grid .menu-item {
    border-radius: 10px;
    padding: 10px;
    text-align: center;
    line-height: normal;
}

.mobile-menu-grid .menu-item img {
    display: block;
    margin: auto;
    height: 80px;
    width: auto;
}

@media only screen and (max-width: 479px){
.mobile-menu-grid .menu-item {
    font-size: 12px;
}
}

</style>


<section class="probootstrap-section">
  <h2 class="text-center judul section-title probootstrap-animate" data-animate-effect="fadeInRight">
                    Security Options </h2>
                <div class="text-center probootstrap-animate" data-animate-effect="fadeInLeft">
                   Some of the best choices for your needs</div>
 <div class="mobile-category-menu"><div class="widget block block-static-block">
    <div class="mobile-menu-grid">
      <div class="menu-item partner probootstrap-animate"><a href="#"><img src="https://atriadimensi.com/directory/app/cctv.png" data-animate-effect="fadeInUp" alt="Jual Paket Cctv">Paket Cctv</a></div>
        <div class="menu-item partner probootstrap-animate"><a href="#"><img src="https://atriadimensi.com/directory/app/smartlock.png" data-animate-effect="fadeInUp" alt="Access Door & Smartlock">Access Door & Smartlock</a></div>
         <div class="menu-item partner probootstrap-animate"><a href="#"><img src="https://atriadimensi.com/directory/app/harddrive.png" data-animate-effect="fadeInUp" alt="Harddisk">Hard Disk Survaillance</a></div>
          <div class="menu-item partner probootstrap-animate"><a href="#"><img src="https://atriadimensi.com/directory/app/mini-ptz.png" data-animate-effect="fadeInUp" alt="Mini Ptz">Mini PTZ</a></div>
         <div class="menu-item partner probootstrap-animate" data-animate-effect="fadeInLeft"><a href="#"><img src="https://atriadimensi.com/directory/app/turnstile.png" alt="Turnstile">Turnstile</a></div>
        <div class="menu-item partner probootstrap-animate" data-animate-effect="fadeInLeft"><a href="#"><img src="https://atriadimensi.com/directory/app/barrier-gate.png"  alt="Barrier Gate">Barrier Gate</a></div>
       <div class="menu-item partner probootstrap-animate" data-animate-effect="fadeInRight"><a href="#"><img src="https://atriadimensi.com/directory/app/metaldetector.png" alt="Smart Entrance Control">Smart Entrance Control</a></div>
       <div class="menu-item partner probootstrap-animate"  data-animate-effect="fadeInRight"><a href="#"><img src="https://atriadimensi.com/directory/app/thermal-cctv.png" alt="Cctv Thermmal">Cctv Thermmal</a></div>
      </div>
     </div>
    </div>
</section>    


<section class="probootstrap-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-left section-heading probootstrap-animate mb0">
                <h2 class="text-center judul section-title probootstrap-animate" data-animate-effect="fadeInRight">
                    Authorized Partner </h2>
                <div class="text-center probootstrap-animate" data-animate-effect="fadeInLeft">
                    Some of our work partners </div>

                <div class="card-body">
                    <div class="row justify-content-center" style="flex-wrap: wrap;">
                        <div class="col-xs-6 mb-4 col-md-4 col-lg-4">
                            <div class="body-container shadow p-2">
                                <img src="https://atriadimensi.com/directory/app/dahua.webp" height="100%" class="partner probootstrap-animate" data-animate-effect="fadeInLeft" alt="dahua">
                            </div>
                        </div>
                        <div class="col-xs-6 mb-4 col-md-4 col-lg-4">
                            <div class="body-container shadow p-2">
                                <img src="https://atriadimensi.com/directory/app/cpplus.webp" height="100%" class="partner probootstrap-animate" data-animate-effect="fadeInRight" alt="cpplus">
                            </div>
                        </div>
                        <div class="col-xs-6 mb-4 col-md-4 col-lg-4">
                            <div class="body-container shadow p-2">
                                <img src="https://atriadimensi.com/directory/app/unv.webp" height="100%" class="partner probootstrap-animate" data-animate-effect="fadeInLeft" alt="unv">
                            </div>
                        </div>
                        <div class="col-xs-6 mb-4 col-md-4 col-lg-4">
                            <div class="body-container shadow p-2">
                                <img src="https://atriadimensi.com/directory/app/perdana.webp" height="100%"class="partner probootstrap-animate" data-animate-effect="fadeInRight" alt="perdana">
                            </div>
                        </div>
                        <div class="col-xs-6 mb-4 col-md-4 col-lg-4">
                            <div class="body-container shadow p-2">
                                <img src="https://atriadimensi.com/directory/app/pegasus.webp" height="100%" class="partner probootstrap-animate" data-animate-effect="fadeInLeft" alt="pegasus">
                            </div>
                        </div>
                        <div class="col-xs-6 mb-4 col-md-4 col-lg-4">
                            <div class="body-container shadow p-2">
                                <img src="https://atriadimensi.com/directory/app/zkteco.webp" height="100%" class="partner probootstrap-animate" data-animate-effect="fadeInRight" alt="zkteco">
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div> 
</section> 

<section class="probootstrap-section probootstrap-bg probootstrap-section-colored " style="background-image: url('<?php echo base_url('themes/enlight/') ?>img/bannerlog.webp');">
	<div class="row">
		<div class="col-md-6 col-md-offset-3 text-center section-heading probootstrap-animate">
			<h2>Latest Post</h2>
			<p class="lead">Find other interesting articles only here</p>
		</div>
	</div>
	<!-- END row -->
	<?php if (count($data_blog) > 0): ?>
	<div id="featured-news" class="tab-pane fade in active">
		<div class="row">
			<div class="col-md-12 probootstrap-animate">
				<div class="owl-carousel" id="owl1">
					<?php foreach ($data_blog as $item): ?>
					<div class="item">
						<a href="<?php echo base_url('blog/'.$item->link) ?>" class="probootstrap-featured-news-box">
							<figure class="probootstrap-media">
								<img src="<?php echo base_url($item->cover) ?>" alt="<?php echo $item->title ?>" class="img-responsive" style="width: 100%; height: 250px; object-fit: cover;">
							</figure>
							<div class="probootstrap-text">
								<div style="height: 50px; overflow: hidden;">
									<h3 style="text-overflow: ellipsis; overflow: hidden; color: #151515; line-height: 1.2; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;" title="<?php echo $item->title ?>">
										<?php echo $item->title ?>
									</h3>
								</div>
								<div style="height: 90px; overflow: hidden;">
									<p style="text-overflow: ellipsis; margin-top: 20px; line-height: 1.2; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical;"><?php echo $item->snippet ?></p>
								</div>
								<div class="probootstrap-date" style="font-size: 13px;">
									<i class="icon-calendar"></i><?php echo date("d M Y", strtotime($item->created_at)) ?>
									<?php if ($item->is_comment == 1): ?>
									<div style="float: right;">
										<i class="zmdi zmdi-comments"></i> <?php echo number_format((int)$item->comment_count) ?>
									</div>
									<?php endif; ?>
								</div>
							</div>
						</a>
					</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
		<!-- END row -->
		<div class="row">
			<div class="col-md-12 text-center">
				<p><a href="<?php echo base_url('blog') ?>" class="btn btn-primary">View all posts</a></p>  
			</div>
		</div>
	</div>
	<?php else: ?>
	<div class="nothing-found"><div>No data found</div></div>
	<?php endif; ?>
</section>

<!-- <section class="probootstrap-section probootstrap-bg probootstrap-section-colored probootstrap-testimonial" style="background-image: url('<?php echo base_url('themes/enlight/') ?>img/testimonial.jpg'); margin-left: -180px; margin-right: -180px;">
	<div class="row">
		<div class="col-md-6 col-md-offset-3 text-center section-heading probootstrap-animate">
			<h2>Last Testimonial</h2>
			<p class="lead">The content below is original</p>
		</div>
	</div>

	<?php if (count($data_testimonial) > 0): ?>
	<div class="row">
		<div class="col-md-12 probootstrap-animate">
			<div class="owl-carousel owl-carousel-testimony owl-carousel-fullwidth">
				<?php foreach ($data_testimonial as $item): ?>
				<div class="item">
					<div class="probootstrap-testimony-wrap text-center">
						<figure>
							<img src="<?php echo base_url($item->creator_photo) ?>" alt="<?php echo $item->creator_name ?>" style="object-fit: cover;">
						</figure>
						<blockquote class="quote">&ldquo;<?php echo $item->content ?>&rdquo; <cite class="author"> &mdash; <span><?php echo $item->creator_name ?></span></cite></blockquote>
					</div>
				</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<?php else: ?>
	<div class="nothing-found"><div>No data found</div></div>
	<?php endif; ?>
	
</section> -->

<section class="probootstrap-section">
    <div class="container">
        <div class="row-polio">
            <div class="col-md-12 text-left section-heading probootstrap-animate mb0">
              <div class="main">
                <h2 class="text-center judul section-title probootstrap-animate" data-animate-effect="fadeInRight">
                    Portfolio</h2>
                    <div class="text-center probootstrap-animate" data-animate-effect="fadeInLeft">
                    This Is Our Portfolio to be Used as your reference material to assess the results of our work in the project. </div>
                  
                    <!-- Portfolio Gallery Grid -->
                    <div class="row-polio">
                       <div class="column">
                          <div class="content">
                             <img src="https://atriadimensi.com/directory/app/indofood-1.webp" height="100%" class="partner probootstrap-animate" data-animate-effect="fadeInUp" alt="Work at Indofood" style="width:80%">
                          <h4 class="subtitle">Access Door</h4>
                         <p>Lokasi : Indofood CBP.</p>
                      </div>
                   </div>
                   <div class="column">
                      <div class="content">
                         <img src="https://atriadimensi.com/directory/app/transera-2.webp" height="100%" class="partner probootstrap-animate" data-animate-effect="fadeInUp" alt="Work at Transera Waterpark" style="width:80%">
                         <h4 class="subtitle">Proses Pemasangan CCTV</h4>
                         <p>Lokasi : Head Office Transera Waterpark</p>
                      </div>
                   </div>
                   <div class="column">
                      <div class="content">
                         <img src="https://atriadimensi.com/directory/app/rs-persahabatan-3.webp" height="100%" class="partner probootstrap-animate" data-animate-effect="fadeInLeft" alt="Work at RS Persahabatan" style="width:80%">
                         <h4 class="subtitle">Installing CCTV</h4>
                         <p>Lokasi : RS Persahabatan</p>
                      </div>
                   </div>
                   <div class="column">
                      <div class="content">
                         <img src="https://atriadimensi.com/directory/app/indofood-4.webp" height="100%" class="partner probootstrap-animate" data-animate-effect="fadeInRight" alt="Work at Indofood" style="width:80%">
                         <h4 class="subtitle">Dokumentasi Pasang Tripod Turnstile</h4>
                         <p>Lokasi : PT Indofood CBP</p>
                      </div>
                   </div>
                   <!-- END GRID -->
                </div>
                <div class="content">
                   <img src="https://atriadimensi.com/directory/app/lexus-5.webp" height="100%" class="partner probootstrap-animate" data-animate-effect="fadeInUp" alt="Work at Shoroom Lexus" style="width:60%">
                     <h4 class="subtitle">Pemasangan CCTV di Showroom Lexus Menteng Jakarta</h4>
                    <p>Lokasi : Showroom Lexus , Menteng Jakarta Pusat. Progress Installasi cctv IP Camera tahap akhir
                   <br>Wallmount Rack By @indorackofficial, Hardisk Toshiba By @perdana_tsb</p>
                </div>
                <!-- END MAIN -->
                </div>
                
                  </div>
              </div>
        </div> 
 </section>
                
    <section class="probootstrap-section" style="padding-bottom: 0px;">
        	<div class="row">
            	<div class="col-md-6 col-md-offset-3 text-center section-heading probootstrap-animate">
        			<h2 class="judul">Our Services</h2>
                		<p class="lead">The reason why you have to choose us</p>
                		</div>
                	</div>
                	<?php if (count($data_service) > 0): ?>
                	<div class="row">
                		<?php foreach ($data_service as $item): ?>
                		<div class="col-md-4">
                			<div class="service left-icon probootstrap-animate">
                				<div class="icon"><i class="zmdi <?php echo $item->icon ?>"></i></div>
                				<div class="text">
                					<h3><?php echo $item->name ?></h3>
                					<p><?php echo $item->description ?></p>
                				</div>  
                			</div>
                		</div>
                		<?php endforeach; ?>
                	</div>
                	<?php else: ?>
                	<div class="nothing-found"><div>No data found</div></div>
                	<?php endif; ?>
        </section>

