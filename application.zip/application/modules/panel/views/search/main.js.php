<script type="text/javascript">
  $(document).ready(function()
  {

    $('#table-search-blog').DataTable({
      searching: false,
      ordering: false,
      lengthChange: false,
      // drawCallback: function( settings ) {
      //   $("#table-search-blog thead").remove();
      // }
    });

    $('#table-search-page').DataTable({
      searching: false,
      ordering: false,
      lengthChange: false,
      // drawCallback: function( settings ) {
      //   $("#table-search-page thead").remove();
      // }
    });

  });
</script>
