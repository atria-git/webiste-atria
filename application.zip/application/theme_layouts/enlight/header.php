<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title>{title}</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
<!--<meta content="<?php echo $app->app_description ?>" name="description">-->
<!-- Google / Search Engine Tags -->
<meta itemprop="name" content="Atria Dimensi Solusindo - The Security Solutions">
<!--<meta itemprop="description" content="PT Atria Dimensi Solusindo, Menyediakan layanan system security CCTV, Access Door, Turnstile, Smarthome untuk anda, Mau Pasang CCTV di Bekasi - Paket CCTV Murah - IP Camera - Kami Authorized Distributor CP PLUS & DAHUA | Hubungi 081908232299 untuk konsultasinya">-->
<meta
  name="description"           
  content="Menyediakan Pengadaan dan Pemasangan CCTV, System security, 
    Access Door, Barrier Gate, Turnstile dan Visitor Management dengan kualitas harga terbaik">

<!-- nyobain -->
<meta itemprop="image" content="https://atriadimensi.com/directory/app/paket-2-camera-ramadhan.webp">
<meta data-rh="true" name="page-type" content="find-desktop">
<meta data-rh="true" name="title" content="Jual Paket Cctv 4 Kamera di Bekasi - Harga Terbaru 2021">

<link data-rh="true" rel="preload" href="https://atriadimensi.com/directory/app/paket-2-camera-ramadhan.webp" crossorigin="anonymous" as="image" type="image/webp">

<!-- Facebook Meta Tags -->
<meta property="og:url" content="https://atriadimensi.com">
<meta property="og:type" content="website">
<meta property="og:title" content="Atria Dimensi Solusindo - The Security Solutions">
<meta property="og:description" content="Menyediakan Pengadaan dan Pemasangan CCTV, System security, Access Door, Barrier Gate, Turnstile dan Visitor Management dengan kualitas harga terbaik ">
<meta property="og:image" content="https://atriadimensi.com/directory/app/paket-4-camera-ramadhan.webp">

<!-- Twitter Meta Tags -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Atria Dimensi Solusindo - The Security Solutions">
<meta name="twitter:description" content="Menyediakan jasa dan pengadaan layanan sistem security CCTV, Access Door, Turnstile, Barrier Gate, Visitor Management sampai produk Smarthome,
          Mau Pasang CCTV di Bekasi - Tersedia Paket CCTV - Kami Authorized Distributor CP PLUS & DAHUA 
         .Hubungi 081908232299 untuk konsultasi">
<meta name="twitter:image" content="https://atriadimensi.com/directory/app/paket-4-camera-ramadhan.webp">
<meta name="keywords" content="paket cctv bekasi,atria dimensi solusindo, jasa pasang cctv bekasi,vendor cctv, pengadaan cctv,pengadaan accessdoor,cctv bekasi barat,toko cctv bekasi timur, toko cctv bekasi,pasang cctv murah,paket cctv,paket cctv cpplus,
            CP-VAC-D24L2,CP-VAC-T24PL2,cctv cpplus,cctv cpplus 5mp,cpplus 5mp,pasang cctv,instalasi cctv,paket cctv murah,cctv murah,toko cctv murah,jual cctv,toko cctv,jual paket cctv,cctv jakarta,toko cctv jakarta,cctv depok,toko cctv depok,cctv bekasi,
            toko cctv bekasi,cctv tangerang,toko cctv tangerang,pasang cctv murah,pasang cctv jakarta,pasang cctv depok,pasang cctv tangerang,pasang cctv bekasi,jual paket cctv murah,jual paket cctv jakarta,
            jual paket cctv bogor,jual paket cctv depok,jual paket cctv tangerang,jual paket cctv bekasi,jual cctv murah,jual cctv jakarta,jual cctv tangerang,jual cctv bekasi,pasang paket cctv,pasang paket cctv murah,
            pasang paket cctv jakarta,pasang paket cctv depok,pasang paket cctv tangerang,pasang paket cctv bekasi,jasa pasang cctv,toko cctv terdekat,jual cctv,jual paket cctv,pasang cctv bekasi,dahua,jual cctv dahua,
            Pt Atria Dimensi Solusindo,Atria,cp plus,cctv bali tower,cctv galaxy,pasang cctv,cctv murah,cctv rumah,cctv kantor,cctv bekasi,kamera pengawas" />
            
  <meta name="google-site-verification" content="7muyeRNgYN4ukENc75NngWzUOh8zv_5eXk8pNR_EBM0" />
  <meta property="og:locale" content="en_US">
  <meta property="og:type" content="website">
  <meta property="og:title" content="Atria Dimensi Solusindo - The Security Solutions">
  <meta property="og:description" content="Menyediakan jasa dan pengadaan layanan sistem security CCTV, Access Door, Turnstile, Barrier Gate, Visitor Management sampai produk Smarthome,
          Mau Pasang CCTV di Bekasi - Tersedia Paket CCTV - Kami Authorized Distributor CP PLUS & DAHUA 
         .Hubungi 081908232299 untuk konsultasi">
  
  <link rel="canonical" href="https://atriadimensi.com/about">
  
  <meta name="theme-color" content="#32c787"/>
  <meta name="robots" content="index, follow, noodp">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="#32c787">
  
  <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async defer src="https://www.googletagmanager.com/gtag/js?id=G-CHEZ4BD5S4"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
       gtag('js', new Date());
       gtag('config', 'G-DP2YB8JC49');
    </script>
  <!-- Favicons -->
  <link rel="shortcut icon" href="<?php echo base_url($app->app_favicon) ?>" type="image/x-icon">
  <link rel="icon" href="<?php echo base_url($app->app_favicon) ?>" type="image/x-icon">
  <link rel="icon" href="<?php echo base_url($app->app_favicon) ?>" sizes="32x32">
  <link rel="icon" href="<?php echo base_url($app->app_favicon) ?>" sizes="192x192">
  <link rel="apple-touch-icon" href="<?php echo base_url($app->app_favicon) ?>">
  <meta name="msapplication-TileImage" content="<?php echo base_url($app->app_favicon) ?>">
  
  <link rel="stylesheet" href="<?php echo base_url('themes/enlight/') ?>css/styles-merged.css">
  <link rel="preload" href="<?php echo base_url('themes/enlight/') ?>css/styles-merged.css" as="style">
  
  <link rel="preload" href="<?php echo base_url('themes/enlight/') ?>css/style.min.css" as="style">
  <link rel="stylesheet" href="<?php echo base_url('themes/enlight/') ?>css/style.min.css">
  
  <!--<link href="<?php echo base_url('themes/enlight/') ?>css/custom.css" rel="stylesheet" media="all">-->
  
  <link href="<?php echo base_url('themes/enlight/vendor/material-design-iconic-font/css/material-design-iconic-font.min.css') ?>" rel="stylesheet">
 
  <link href="<?php echo base_url('themes/enlight/vendor/font-awesome/css/font-awesome.min.css') ?>" rel="stylesheet">
  <link href="<?php echo base_url('themes/enlight/vendor/lightbox/css/lightbox.min.css') ?>" rel="stylesheet">

<link 
 as="style"
 rel="stylesheet preload prefetch" 
 href="<?php echo base_url('themes/enlight/') ?>css/custom.css" 
 type="text/css"
 crossorigin="anonymous" />
 
  <!-- Template Public Main CSS File -->
 <link href="<?php echo base_url('themes/_public/css/public.main.css') ?>" rel="stylesheet">
  
  
</head>

<body>
