  <!--==========================
    Footer
  ============================-->
  <style>
.judulfooter{
  line-height: 26px;
  font-size: 22px;
  color: #fafdfc;

}  
.tombolWaFixed {
    position: fixed;
    bottom: 25px;
    right: 60px;
    display: flex;
    justify-content: center;
    align-items: center;
    box-shadow: rgb(0 0 0 / 12%) 0px 2px 8px 0px;
    height: 55px;
    width: 200px;
    border-radius: 15px;
    font-size: 1.8vh;
    background-color: #32c787;
    cursor: pointer;
    z-index: 9999999;

}
.pulse2 {
    color: red;
    animation-name: pulse2;
    animation-duration: 1s;
    animation-iteration-count: infinite;
    animation-timing-function: linear;
}
@media (max-width: 767px){
.hidden-xs {
    display: none!important;
}
}
@media only screen and (max-width: 740px){
.floatingNav {
    display: flex;
    position: fixed;
    bottom: 0;
    width: 100%;
    height: 50px;
    z-index: 999999;
    opacity: 0.9;
    font-size: 14px !important;
    line-height: 1.42857143 !important;
}
.floatingNav>div {
    flex: 1;
    text-align: center;
    color: #fff;
    padding: 7px;
    font-weight: bold;

}
}

@media screen and (max-width: 768px){
.probootstrap-footer .probootstrap-back-to-top {
    text-align: right !important;
    margin-top: 30px;
}
.judulfooter{
  line-height: 26px;
  font-size: 22px;
 color: #fafdfc;

}    
    
}
</style>

  <footer class="probootstrap-footer probootstrap-bg probootstrap-page-wrapper">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="probootstrap-footer-widget">
            <h1 class="judulfooter">Kenapa Pilih Atria ? </h1>
            <!--<p><?php echo $app->app_description ?></p>-->
             <ul class="probootstrap-contact-info">
              <li><i class="icon-thumbs-up"></i><span>Barang Berkualitas</span></li>  
              <li><i class="icon-truck"></i><span>Di Support Oleh Distributor Resmi<span></li>
              <li><i class="icon-wrench icon-spin"></i><span>Di Dukung Teknisi Yang Handal</span></li>
              <li><i class="icon-shield"></i><span>Berpengalaman Menangani Project Skala Besar</span></li>
            </ul>
             <h2 class="judulfooter">Social Media</h2>
              <ul class="probootstrap-footer-social">
             
                  <li><a class="fa fa-youtube-play pulse2" aria-label="Youtube" href="https://www.youtube.com/channel/UCtc4bACUo5dFN3P2JQosv1A/featured" rel="noopener noreferrer nofollow" target="_blank">
                      </a>
                  </li>
                  
                  <?php if (!empty($app->contact->facebook)): ?> <li>
                  <a class="icon-facebook2" aria-label="Facebook" href="https://facebook.com/<?php echo $app->contact->facebook ?>" rel="noopener noreferrer nofollow" target="_blank">
                  </a></li>
                  <?php endif; ?>
                  
                  <?php if (!empty($app->contact->instagram)): ?><li>
                  <a class="icon-instagram2" aria-label="Instagram" href="https://instagram.com/<?php echo $app->contact->instagram ?>" rel="noopener noreferrer nofollow" target="_blank">
                  </a></li>
                  <?php endif; ?>
                  
                  <?php if (!empty($app->contact->linkedin)): ?><li>
                  <a class="icon-linkedin" aria-label="Linkedin" href="https://linkedin.com/in/<?php echo $app->contact->linkedin ?>" rel="noopener noreferrer nofollow" target="_blank">
                  </a></li>
                  <?php endif; ?>
              
            </ul>
            
            
          </div>
        </div>
        <div class="col-md-3 col-md-push-1">
          <div class="probootstrap-footer-widget">
            <h2 class="judulfooter">Links</h2>
            <ul>
              <li><a href="<?php echo base_url() ?>">Home</a></li>
              <!-- <li><a href="<?php echo base_url('page/terms-and-conditions') ?>">Terms and Conditions</a></li> -->
              <li><a href="<?php echo base_url('page/managed-services-it') ?>">Managed Services IT</a></li>
               <li><a href="<?php echo base_url('page/promo-paket-cctv') ?>">Paket Cctv</a></li> 
            </ul>
          </div>
        </div>
        <div class="col-md-4">
          <div class="probootstrap-footer-widget">
            <h2 class="judulfooter">Contact Info</h2>
            <ul class="probootstrap-contact-info">
              <li><i class="icon-location2"></i> <span><?php echo $app->contact->address ?></span></li>
              <li><i class="icon-mail"></i><span><?php echo $app->contact->email ?></span></li>
              <li><i class="icon-phone2"></i><span><?php echo $app->contact->phone ?></span></li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    <div class="probootstrap-copyright">
      <div class="container">
        <div class="row">
          <div class="col-md-8 text-left">
            <p>&copy; <?php echo $app->app_name ?>. All Rights Reserved | 2021.
            <br/> Designed &amp; Developed with <i class="icon icon-heart pulse2"></i> by <a href="https://www.linkedin.com/in/achmad-faisal-ramadhan-902678176/" rel="noopener noreferrer nofollow" target="_blank">Faisal Ramadhan</a>
          </div>
          <div class="col-md-4 probootstrap-back-to-top">
            <p><a href="#" class="js-backtotop">Back to top <i class="icon-arrow-long-up"></i></a></p>
          </div>
        </div>
      </div>
    </div>

<section class="tombolWaFixed hidden-xs"><div>
    <a href="https://api.whatsapp.com/send?phone=+6281908232299&text=Hallo :), Saya Mau tanya-tanya boleh?, saya berkunjung di atriadimensi.com &source=&data= " rel="noopener noreferrer nofollow" target="_blank">
        <i class="fa fa-whatsapp fa-lg" style="color: #fff"></i> Order via WA</a>
    </div>
  </section>


<section class="floatingNav hidden-lg hidden-md hidden-sm">
   <div style="background-color: #eaeaea;">
      <a href="https://atriadimensi.com/page/promo-paket-cctv?utm_source=paketcctv&utm_medium=mobileweb&utm_campaign=mobile_click" style="color: #18bb0c;" rel="noopener noreferrer nofollow" target="_blank">
      <i class="fa fa-shopping-bag fa-md" style="color: #0c5a06"></i><br>
      <span style="color: #0c5a06;">Promo Paket Cctv</span>
      </a>
   </div>
   <div style="background: #0c5a06;
      display: flex;
      justify-content: center;
      align-items: center;
      border-right: 1px solid rgba(0,0,0,.1);">
      <a href="https://api.whatsapp.com/send?phone=+6281908232299&text=Hallo :), Saya Mau tanya-tanya boleh?, saya berkunjung di atriadimensi.com &source=&data=" rel="noopener noreferrer nofollow" target="_blank">
      <i class="fa fa-whatsapp fa-lg" style="color: #fff"></i><br>
      <span style="color: #eaeaea;"> Whatsapp</span>
      </a>
   </div>
</section>


  </footer>

  <script src="<?php echo base_url('themes/enlight/') ?>js/scripts.min.js"></script>
  <script src="<?php echo base_url('themes/enlight/') ?>js/main.min.js"></script>
  <script src="<?php echo base_url('themes/enlight/') ?>js/custom.js"></script>
  <script src="<?php echo base_url('themes/enlight/') ?>vendor/lightbox/js/lightbox.min.js"></script>
  <script src="<?php echo base_url('themes/_public/') ?>js/public.fe.js"></script>

</body>
</html>
