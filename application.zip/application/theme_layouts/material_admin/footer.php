        </main>

        <!-- Javascript -->
        <!-- Vendors -->
        <script src="<?php echo base_url('themes/material_admin/vendors/jquery/jquery.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/popper.js/popper.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/bootstrap/js/bootstrap.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/jquery-scrollbar/jquery.scrollbar.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/jquery-scrollLock/jquery-scrollLock.min.js') ?>"></script>

        <script src="<?php echo base_url('themes/material_admin/vendors/flot/jquery.flot.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/flot/jquery.flot.resize.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/flot.curvedlines/curvedLines.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/jqvmap/jquery.vmap.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/jqvmap/maps/jquery.vmap.world.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/easy-pie-chart/jquery.easypiechart.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/salvattore/salvattore.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/sparkline/jquery.sparkline.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/moment/moment.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/fullcalendar/fullcalendar.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/bootstrap-notify/bootstrap-notify.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/sweetalert2/sweetalert2.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/tinymce/tinymce.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/autosize/autosize.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/flatpickr/flatpickr.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/jquery-mask-plugin/jquery.mask.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/select2/js/select2.full.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/nouislider/nouislider.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/lightgallery/js/lightgallery-all.min.js') ?>"></script>

        <!-- Vendors: Data tables -->
        <script src="<?php echo base_url('themes/material_admin/vendors/datatables/jquery.dataTables.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/datatables-buttons/dataTables.buttons.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/datatables-buttons/buttons.print.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/jszip/jszip.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/vendors/datatables-buttons/buttons.html5.min.js') ?>"></script>

        <!-- Charts and maps-->
        <script src="<?php echo base_url('themes/material_admin/demo/js/flot-charts/curved-line.js') ?>"></script>
        <!-- <script src="<?php echo base_url('themes/material_admin/demo/js/flot-charts/dynamic.js') ?>"></script> -->
        <!-- <script src="<?php echo base_url('themes/material_admin/demo/js/flot-charts/line.js') ?>"></script> -->
        <script src="<?php echo base_url('themes/material_admin/demo/js/flot-charts/chart-tooltips.js') ?>"></script>
        <script src="<?php echo base_url('themes/material_admin/demo/js/other-charts.js') ?>"></script>
        <!-- <script src="<?php echo base_url('themes/material_admin/demo/js/jqvmap.js') ?>"></script> -->

        <!-- App functions and actions -->
        <script src="<?php echo base_url('themes/material_admin/js/app.min.js') ?>"></script>
        <script src="<?php echo base_url('themes/_public/js/public.main.js') ?>"></script>

        <?php echo (isset($main_js)) ?  $main_js : '' ?>
    </body>
</html>
