<?php include_once('header.php') ?>

<main id="main">
  {content}
</main>

<?php include_once('footer.php') ?>
